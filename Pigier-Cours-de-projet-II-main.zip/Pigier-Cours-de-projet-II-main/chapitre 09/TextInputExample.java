package ci.pigier;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class TextInputExample extends Application {
    @Override
    public void start(Stage primaryStage) {
        TextField textField = new TextField();
        textField.setPromptText("Entrez votre nom");

        TextArea textArea = new TextArea();
        textArea.setPromptText("Entrez un message");

        VBox root = new VBox(10, new Label("TextField:"), textField,
                             new Label("TextArea:"), textArea);
        root.setPadding(new Insets(20));
        Scene scene = new Scene(root, 400, 300);
        primaryStage.setTitle("Exemple de TextInput");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

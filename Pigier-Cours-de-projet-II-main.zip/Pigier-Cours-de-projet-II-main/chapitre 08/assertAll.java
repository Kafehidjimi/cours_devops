@Test
public void shelfToStringShouldPrintBookCountAndTitles() throws Exception {
	shelf.add("The Phoenix Project");
	shelf.add("Java 8 in Action");
	String shelfStr = shelf.toString();
	assertAll(
			() -> assertTrue(shelfStr.contains("The Phoenix Project"), "1st book title missing"), 
			() -> assertTrue(shelfStr.contains("Java 8 in Action") ,"2nd book title missing "),
			() -> assertTrue(shelfStr.contains("2 books found"), "Book count missing"));

}
